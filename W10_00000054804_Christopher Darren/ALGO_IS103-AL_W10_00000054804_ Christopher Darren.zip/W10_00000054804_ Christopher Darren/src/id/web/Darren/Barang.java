package id.web.Darren;

public class Barang {
	
	public String nama;
	public double harga;
	public double diskon;
	public double total;

}
