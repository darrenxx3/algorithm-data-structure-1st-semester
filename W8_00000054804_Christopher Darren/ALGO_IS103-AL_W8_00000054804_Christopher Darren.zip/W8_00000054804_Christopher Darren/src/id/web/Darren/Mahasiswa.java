package id.web.Darren;

public class Mahasiswa {
	
	public String nama;
	public String jurusan;
	public int nilai_praktikum;

}
