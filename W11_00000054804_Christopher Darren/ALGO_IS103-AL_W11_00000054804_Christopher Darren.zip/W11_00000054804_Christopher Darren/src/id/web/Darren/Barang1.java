package id.web.Darren;

public class Barang1 {
	
	public String nama;
	public double harga;
	public double diskon;
	public double total;

}
