package id.web.Darren;

public class Prak1_3 {
	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Saya\nsuka\nbelajar\nAlgorithm\ndan\npemrograman\n");

	}

}
