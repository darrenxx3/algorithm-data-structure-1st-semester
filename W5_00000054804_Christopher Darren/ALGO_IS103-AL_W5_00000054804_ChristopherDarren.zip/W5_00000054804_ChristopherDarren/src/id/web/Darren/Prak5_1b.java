package id.web.Darren;

public class Prak5_1b {
	public static int Perkalian(int bil_pertama, int bil_kedua) {
		int hasil = bil_pertama * bil_kedua;
		return hasil;  // int berusaha mengembalikan variable ke public void.
		
		
	}

}
