package id.web.Darren;
import java.util.Scanner;
public class Prak9_2b_TestInputData {
	
	public static void main(String[] args) {
		Prak9_2 cobaCreate = new Prak9_2();
		cobaCreate.bukaFile(args);
		cobaCreate.menambahData();
		cobaCreate.menutupFile();
	}
	
}
