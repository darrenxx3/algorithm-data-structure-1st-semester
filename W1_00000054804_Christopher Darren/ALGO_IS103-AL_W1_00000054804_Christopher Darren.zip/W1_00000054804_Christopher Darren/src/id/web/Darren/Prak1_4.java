package id.web.Darren;

public class Prak1_4 {
	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Saya");
		System.out.println("suka");
		System.out.println("belajar");
		System.out.println("Algorithma");
		System.out.println("dan");
		System.out.println("pemrograman");
		

	}

}
