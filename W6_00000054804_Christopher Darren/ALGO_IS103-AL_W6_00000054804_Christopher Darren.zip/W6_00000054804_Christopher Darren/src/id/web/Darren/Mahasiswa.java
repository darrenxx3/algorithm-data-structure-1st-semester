package id.web.Darren;

public class Mahasiswa {
	String nama;
	String nim;
	float ipk;

}
