package id.web.Darren;

public class Prak1_6 {
	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.printf("HITUNG PERKALIAN\n");
		System.out.printf("Bilangan pertama adalah %d\n", 5);
		System.out.printf("Bilangan kedua adalah %x\n" , 10);
		System.out.printf("Bilangan ketiga adalah %o\n" , 15);
		System.out.printf("Bilangan keempat adalah %f\n", 3.97);
		System.out.printf("Bilanag kelima adalah %g\n", 0.00000678);
		System.out.printf("Bilangan keenam adalah %s\n", 25);
	

	}

}
