package id.web.Darren;

public class Challenge_1 {
	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Semester 1: ");
		System.out.printf("%s %s %31s", "No.", "Nama Mata kuliah", "Nilai\n");
		System.out.println("-----------------------------------------------------");
		System.out.printf("%3s %3s %10s\n", 1, "Pengantar Teknologi Sistem Informasi", "90.75");
		System.out.printf("%3s %3s %23s\n",2, "Dasar-dasar Pemrograman", "99.95");
		System.out.printf("%3s %1s %37s ", 3, "Inggris 1", "96.83" );
			

	}

}
