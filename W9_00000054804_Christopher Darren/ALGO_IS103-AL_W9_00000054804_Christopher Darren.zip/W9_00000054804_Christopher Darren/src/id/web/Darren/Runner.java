package id.web.Darren;
import java.util.Scanner;
public class Runner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

	}

	public String nama;
	public String kecepatan;

}
