package id.web.Darren;

public class Prak9_3b_readdata {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Prak9_3 myapp = new Prak9_3();
		
		myapp.bukaFile();
		myapp.membacaData();
		myapp.menutupFile();
		

	}

}
