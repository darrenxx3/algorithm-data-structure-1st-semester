package id.web.Darren;

public class Prak1_2 {
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Saya");
		System.out.print("suka");
		System.out.print("belajar");
		System.out.print("Algorithma");
		System.out.print("dan");
		System.out.print("pemrograman");

	}

}
