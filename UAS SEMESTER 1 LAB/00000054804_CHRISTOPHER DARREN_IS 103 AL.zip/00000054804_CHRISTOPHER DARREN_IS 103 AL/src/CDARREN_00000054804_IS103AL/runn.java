package CDARREN_00000054804_IS103AL;

public class runn {
	 String nama ;
	 String kecepatan;
}
