package id.web.Darren;

public class Penduduk {
	String Nama;
	String JKelamin;
	String tgl;
	String Goldarah;
	String Pekerjaan;

}
