package id.web.Darren;

public class Prak1_1 {
	
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Saya suka belajar Algoritma dan pemrograman");

	}

}
