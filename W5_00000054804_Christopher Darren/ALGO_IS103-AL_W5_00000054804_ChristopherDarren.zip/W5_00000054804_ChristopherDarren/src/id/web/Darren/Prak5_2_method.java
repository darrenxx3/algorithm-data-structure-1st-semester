package id.web.Darren;

public class Prak5_2_method {
	public static int persegi(int sisi) {
		int luas = sisi * sisi;
		return luas;
		
		public static int persegi_panjang(int panjang,int lebar) {
		int luas = panjang * lebar;
		return luas;
		
		public static double segitiga(int alas, int tinggi) {
			double luas = (double) 0.5 * alas * tinggi;
			return luas;
		}
			
		}
	}

}
