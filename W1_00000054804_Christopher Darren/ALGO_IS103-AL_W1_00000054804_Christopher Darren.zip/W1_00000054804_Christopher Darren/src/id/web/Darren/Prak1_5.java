package id.web.Darren;

public class Prak1_5 {
	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Saya suka belajar\n");
		System.out.println("Algoritma dan\t permograman");

	}

}
