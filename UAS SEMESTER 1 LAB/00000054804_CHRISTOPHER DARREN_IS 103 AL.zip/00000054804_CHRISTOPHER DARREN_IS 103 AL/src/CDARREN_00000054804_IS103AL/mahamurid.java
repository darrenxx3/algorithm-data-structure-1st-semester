package CDARREN_00000054804_IS103AL;

public class mahamurid {
	
	
	public int angka;
	public String nama;
	public float ipk;
	public int nim_;
	;
	
}
